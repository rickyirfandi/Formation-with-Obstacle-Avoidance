﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KinematicData {

  public  Vector3 _velocity;  //vector3 tipe data yg menampung nilai x,y,z
  public  Vector3 _rotation;
}
