﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Latihan1 : MonoBehaviour {
	public Transform _target;
	public int _maxSpeed;
	public int _maxAcceleration;
	public Vector3 velocity = Vector3.zero;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		this.transform.position = transform.position + velocity*Time.deltaTime;
		velocity = velocity + getSteering ()._linear * Time.deltaTime;
		if (velocity.magnitude > _maxSpeed) {
			velocity.Normalize ();
			velocity = velocity * _maxSpeed;
		}

	}
	public SteeringData getSteering(){
		SteeringData _KinematicOut = new SteeringData();
		_KinematicOut._linear = _target.position - this.transform.position; //#direction
		_KinematicOut._linear = _KinematicOut._linear.normalized; // normalize membuat resultan vektor = 1.
		_KinematicOut._linear *= _maxAcceleration;
		// this.transform.eulerAngles = getNewOrientation(this.transform.eulerAngles, _KinematicOut._velocity); //rotation menggunakan euler angle
		_KinematicOut._angular = Vector3.zero;
		return _KinematicOut;
	}
	public Vector3 getNewOrientation(Vector3 _currentOrientation, Vector3 _velocity)
	{
		//Make sure we have a velocity
		if (_velocity.magnitude > 0) //length didapat dri fungsi magnitude (mendapatkan resultan)
		{
			//Calculate orientation using an arc tangent of the velocity components.
			float radian = Mathf.Atan2(_velocity.x, _velocity.z); //dalam radian, tidak perlu minus karena rotasi unity searah jarum jam
			float angle = radian * (180/Mathf.PI);  // untuk mengganti ke angle
			Vector3 newOrientation = new Vector3(0,angle,0);
			return newOrientation;
		}

		//Otherwise use the current orientation
		else
			return _currentOrientation;
	}

}
